﻿using System;

namespace nicola.mancini._3h.CercaNumero
{
    class Program
    {
        static void Main(string[] args)
        {
        Random random = new Random();
        Console.WriteLine("programma scritto da nicola mancini");

            Console.WriteLine("Inserisci la grandezza del vettore: ");
            string strL = Console.ReadLine();
            int.TryParse(strL, out int L);

            int[] v = new int[L];

            //carico il vettore
            Console.WriteLine("Il vettore e': ");
            for(int i = 0; i < v.Length; i++)
            {
                v[i] = random.Next(1, 100);
                Console.WriteLine(v[i]);
            }

            //metto il vettore in ordine 
            for(int i = 0; i < v.Length-1; i++)
            {
                for(int j = i+1; j < v.Length; j++)
                {
                    if(v[i] > v[j])
                    {
                        int tmp = v[i];
                        v[i] = v[j];
                        v[j] = tmp;
                    }
                }
            }

            //stampo il vettore
            Console.WriteLine("Il vettore è: ");    
            for(int i = 0; i < v.Length; i++)
            {
                Console.WriteLine(v[i]);
            }


            //dichiaro le variabili
            int d = v.Length-1, s = 0;
            int m = 0;
            string strNum = " ";

            //chiedo il numero che si vuole cercare
            Console.WriteLine("Quale e' il numero che vuoi cercare? ");
            strNum = Console.ReadLine();

            int.TryParse(strNum, out int n);

            //cerco il numero
            do
            {
                m = (s+d) / 2;
                if(n == v[m])
                    break;

                if(n < v[m])
                    d = m;
                else
                    s = m;

            }while(s != d && v[m] != n);

            if(v[m] == n)
                Console.WriteLine(m);
            else   
                Console.WriteLine("il numero non e' presente nel vettore");
        }

        
        }
    }
